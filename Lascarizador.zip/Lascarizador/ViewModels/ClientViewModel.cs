﻿using Lascarizador.Core.Models;

namespace Lascarizador.ViewModels
{
    public class ClientViewModel
    {
        public Client Client { get; set; }
    }
}