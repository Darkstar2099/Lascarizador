﻿using Lascarizador.Core.Models;

namespace Lascarizador.ViewModels
{
    public class IndexClientViewModel
    {
        public Client Client { get; set; }
    }
}