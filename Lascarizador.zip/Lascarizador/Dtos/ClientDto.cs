﻿namespace Lascarizador.Dtos
{
    public class ClientDto
    {
        //CPF do cliente
        public string cpf { get; set; }

        //Email do cliente
        public string email { get; set; }

        //Nome do cliente
        public string name { get; set; }
    }
}