﻿namespace Lascarizador.Dtos
{
    public class TransactionTypeDto
    {
        // Número identificador do tipo de transação
        public byte id { get; set; }

        //Descrição do tipo de transacão
        public string type { get; set; }
    }
}