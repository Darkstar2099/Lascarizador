﻿namespace Lascarizador.Dtos
{
    public class CardTypeDto
    {
        //Número identificador do tipo do cartão
        public byte id { get; set; }

        //Nome do tipo do cartão
        public string name { get; set; }
    }
}