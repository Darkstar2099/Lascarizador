﻿namespace Lascarizador.Dtos
{
    public class CardBrandDto
    {
        // Número identificador da banderia do cartão
        public byte id { get; set; }

        //Nome da bandeira do cartão
        public string name { get; set; }
    }
}